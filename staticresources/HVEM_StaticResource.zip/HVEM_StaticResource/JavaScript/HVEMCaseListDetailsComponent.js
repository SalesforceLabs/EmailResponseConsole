/*
* show clicked queue as selected and also remove highlight on other queue.
*/
function showQueueSelected(selectedElement){
	var previousSelectedQueue = document.getElementById('idSelectedQueue').value;
	if(document.getElementById(previousSelectedQueue) != '' && document.getElementById(previousSelectedQueue) !=null){
		document.getElementById(previousSelectedQueue).style.backgroundColor = '';
		document.getElementById(previousSelectedQueue).style.border = '0px';
	}
	
	document.getElementById('idSelectedQueue').value= selectedElement.id;
	selectedElement.style.backgroundColor = '#effaff';
	selectedElement.style.border = '1px solid #b3c0c9';
	storeSelectedQueuePageId(selectedElement.id);
}
