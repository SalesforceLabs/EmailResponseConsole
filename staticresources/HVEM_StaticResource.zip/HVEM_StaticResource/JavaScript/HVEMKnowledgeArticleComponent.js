function setCurrentId(element){
  document.getElementById('idCurrentArticleHidden').value = element.parentNode.id;
}
function setStyleClass(element){

	var previousId = document.getElementById('idPreviousArticleHidden').value;
	var currentId = document.getElementById('idCurrentArticleHidden').value;
	document.getElementById(previousId).className = "hvemCaseItem";
	document.getElementById(currentId).className = "hvemCaseItemSelection";

	document.getElementById('idPreviousArticleHidden').value = document.getElementById(currentId).id;
}


function setFirstArticleStyle(){
	if(document.getElementById('HVEMKnowledgeArticlePageId:KnowledgeArticleComId:HVEMKnowledgeArticleCompId:HVEMKnowledgeArticleFormId:SearchResultId:idArticlePageBlockTable:0:idSingleArticlePanel') != null){
		document.getElementById('HVEMKnowledgeArticlePageId:KnowledgeArticleComId:HVEMKnowledgeArticleCompId:HVEMKnowledgeArticleFormId:SearchResultId:idArticlePageBlockTable:0:idSingleArticlePanel').className = "hvemCaseItemSelection";
	}
	document.getElementById('idPreviousArticleHidden').value="HVEMKnowledgeArticlePageId:KnowledgeArticleComId:HVEMKnowledgeArticleCompId:HVEMKnowledgeArticleFormId:SearchResultId:idArticlePageBlockTable:0:idSingleArticlePanel";
}

function toggleFilters(show) {
  var filters = document.getElementById('searchFilters');
  var filtersToggle = document.getElementById('searchFiltersToggle');
  if (show) {
	  filters.style.display = 'table-row';
	  filtersToggle.style.display = 'none';
  } else {
	  filters.style.display = 'none';
	  filtersToggle.style.display = 'table-row';
  }  
}

function fetchSelection(){          
	  document.getElementById('HVEMKnowledgeArticlePageId:KnowledgeArticleComId:HVEMKnowledgeArticleCompId:HVEMKnowledgeArticleFormId:HVEMKnowledgeArticleFilterPageBlockId:SearchButtonId').focus();
	  if(categoryGroupNames != null && categoryGroupNames != ''){
		  var CategoryGroupsList = categoryGroupNames.split(",");          
		  var withDataCategoryClause = '';  
		  for(var i = 0; i < CategoryGroupsList.length; i++){
			  var singleCategoryGroupName = document.getElementById('categoryType_'+CategoryGroupsList[i]);              
			  if(singleCategoryGroupName != null && singleCategoryGroupName.value != 'No Filter' ){    
				  withDataCategoryClause = withDataCategoryClause + singleCategoryGroupName.value +' AND ';
			  }                            
		  }
		  if(withDataCategoryClause != ''){              
			  withDataCategoryClause = withDataCategoryClause.substr(0,withDataCategoryClause.length-4);
			  withDataCategoryClause = 'WITH DATA CATEGORY ' + withDataCategoryClause;
		  } 
		  //runSearch(withDataCategoryClause,'page');                               
		  refreshSearchResultAF(withDataCategoryClause,'page');
	  }          
  } 
