 function freezeBackground(){
  document.getElementById('disablingDiv').style.display='block';
  document.getElementById('loadingImage').style.display='block';
}  

  function unFreezeBackground(){
	  document.getElementById('disablingDiv').style.display='none';
	  document.getElementById('loadingImage').style.display='none';
  }